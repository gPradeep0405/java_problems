package Day8;

public class CaLculator {
	public int add(int a, int b) {
        return a + b;
    }

    
    public int add(int a, int b, int c) {
        return a + b + c;
    }

    
    public double add(double x, double y) {
        return x + y;
    }

    public static void main(String[] args) {
        CaLculator sc = new CaLculator();

        
        System.out.println("Sum of 15 and 3: " + sc.add(15, 3));
        System.out.println("Sum of 12, 2, and 4: " + sc.add(12, 2, 4));
        System.out.println("Sum of 2.0 and 3.7: " + sc.add(2.0, 3.7));
    }

}
