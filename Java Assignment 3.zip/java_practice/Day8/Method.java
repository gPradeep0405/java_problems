package Day8;
class Animalss {
    public void makeSound() {
        System.out.println("Animal makes sound");
    }
}

class Dogs extends Animalss{
    @Override
    public void makeSound() {
        System.out.println("Dog barks");
    }
}
public class Method {

	public static void main(String[] args) {
		Animalss animal = new Animalss();
        Dogs Dog = new Dogs();

       
        animal.makeSound();
        Dog.makeSound(); 

	}

}
