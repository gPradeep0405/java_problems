package Day8;
class AniMals {
    public void makeSound() {
        System.out.println("animal makes sound");
    }
}

class Dogss extends AniMals {
    @Override
    public void makeSound() {
        System.out.println("Dog barks");
    }
}

public class Dem {
	public static void printSound(AniMals a) {
        a.makeSound(); 
    }

    public static void main(String[] args) {

    	AniMals Ani_mal = new AniMals();
        Dogss D_og = new Dogss();

        
        printSound(Ani_mal); 
        printSound(D_og); 
    }

}
