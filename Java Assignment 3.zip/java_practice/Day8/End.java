package Day8;
final class Carsss {
    private String model;

    public Carsss(String model) {
        this.model = model;
    }

    public final String getModel() {
        return model;
    }
}
public class End {
	public static void main(String[] args) {
        Carsss C_ar = new Carsss("Telsa Model S");
        System.out.println("Car Model: " + C_ar.getModel());
    }

}
