package day7;
abstract class  Vehical
{
    String make;
    String model;
    public Vehical(String make,String model)
    {
        this.make=make;
        this.model=model;
    }

}
abstract class Fourwheeler extends Vehical
{
    int numdoors;
    public Fourwheeler(String make, String model, int numdoors)
    {
        super(make,model);
        this.numdoors=numdoors;
    }

}
abstract class Twowheeler extends Vehical
{
    String type;
    public Twowheeler(String make,String model,String type)
    {
        super(make,model);
        this.type=type;
    }

}
class bike extends Twowheeler
{
    public bike(String make,String model,String type)
    {
        super(make,model,type);

    }
    public void displaybike()
    {
    	System.out.println("        For TwoWheelers");
    	System.out.println("make:  "+make);
        System.out.println("model: "+ model);
        System.out.println("type:  "+type);
    }

}
class car extends Fourwheeler
{
    public car(String make,String model,int numdoors)
    {
        super(make,model,numdoors);

    }
    public void displaycar()
    {
    	System.out.println("       For FourWheelers");
    	System.out.println("make:  "+make);
        System.out.println("model:  "+ model);
        System.out.println("number of doors:  "+numdoors);
    }

}
public class VeHicals {

	public static void main(String[] args) {
		car sc=new car("yamato","wew",4);
        sc.displaycar();
        bike ob=new bike("bmw","er","sport");
        ob.displaybike(); 

	}

}
