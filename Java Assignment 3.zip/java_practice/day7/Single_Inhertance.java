package day7;
import java.util.*;
class Person{
	String Name;
    int age;
    public Person(String Name,int age){
    	this.Name=Name;
    	this.age=age;
    }
}
class Employee extends Person{
    String Employee_id;
    String Department;
	public Employee(String Name, int age,String Employee_id,String Department)
	{
		super(Name,age);
		this.Employee_id=Employee_id;
		this.Department=Department;
	}
	public void Display() {
		System.out.println("Employee Name:"+Name);
		System.out.println("Employee Age:"+age);
		System.out.println("Employee Id:"+Employee_id);
		System.out.println("Employee Department:"+Department);
		
	}
}



public class Single_Inhertance {

	public static void main(String[] args) {
				
		Employee Obj=new Employee("Pradeep",19,"E24","MD");
		
		Obj.Display();


	}

}
